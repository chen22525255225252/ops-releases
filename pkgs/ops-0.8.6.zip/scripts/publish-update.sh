#!/usr/bin/env bash
# ============================================================================
# 发布一次产品更新（打包机上跑；用户端「发现新版本」立即生效）
#
#   用法：bash scripts/publish-update.sh [--notes "说明1;说明2"] [--dry-run]
#
# 做什么：
#   1) 取「上次发布点」（.update-last-publish）到 HEAD 的 git diff 变更文件；
#   2) 校验 package-lock.json 未变（依赖有变时中止——那种情况需要全量安装包）；
#   3) 组装「变更文件包」zip（改动文件 + web/dist 全量；剔除私有/用户数据）；
#   4) 写入 GitHub 发布仓（默认 chen22525255225252/ops-releases，首次自动创建）
#      → tag v<版本> → 更新仓内 ops-update.json（manifest）→ push；
#   5) purge jsDelivr 缓存（几秒后全网生效）；
#   6) 记录新的 .update-last-publish。
#
# 前置：gh 已登录（一次）：gh auth login
#       工作区已提交（本脚本只发布已提交内容）
# ============================================================================
set -euo pipefail

REPO="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO"

GH_REPO="${OPS_REPO:-chen22525255225252/ops-releases}"
NOTES=""
DRY=0
while [ $# -gt 0 ]; do
  case "$1" in
    --notes) NOTES="$2"; shift 2 ;;
    --dry-run) DRY=1; shift ;;
    *) echo "[错误] 未知参数：$1" >&2; exit 1 ;;
  esac
done

VERSION="$(node -p "require('./package.json').version")"
LAST_FILE="$REPO/.update-last-publish"
LAST="$(cat "$LAST_FILE" 2>/dev/null || git rev-parse HEAD^)"
echo "== 发布更新 v${VERSION}（自 ${LAST:0:9} 起的变更） =="

if ! git diff --quiet || ! git diff --cached --quiet; then
  echo "[错误] 工作区有未提交改动——本脚本只发布已提交内容（先 commit）" >&2; exit 1
fi

command -v gh >/dev/null || { echo "[错误] 缺 gh（brew install gh），并先 gh auth login" >&2; exit 1; }

# 1) 变更文件
CHANGED="$(git diff --name-only "$LAST"..HEAD || true)"
if [ -z "$CHANGED" ]; then echo "[错误] ${LAST:0:9}..HEAD 之间没有任何变更——没有可发布内容" >&2; exit 1; fi
# 依赖守卫：package-lock 的「依赖内容」变了才拒绝；仅版本号字段（npm version 会同步它）不算依赖变化
if echo "$CHANGED" | grep -q '^package-lock.json$'; then
  LOCK_SEMANTIC="$(git diff "$LAST"..HEAD -- package-lock.json | grep -E '^[+-][^+-]' | grep -viE '^[+-][[:space:]]*"version"' || true)"
  if [ -n "$LOCK_SEMANTIC" ]; then
    echo "[错误] 依赖有变化（package-lock.json 的依赖内容改了）——此版无法走小包更新，请走完整安装包分发；" >&2
    echo "       （把依赖变更拆到单独版本，或后续支持 full 包后重试）" >&2
    exit 1
  fi
  echo "   （package-lock 仅版本号字段变化——按纯版本更新继续）"
fi

# 2) 构建前端产物（web/dist 每次全带）
echo "-- 构建前端产物"
npm run build:web >/dev/null

# 3) 组装 zip（改动文件 + web/dist 全量；私有/用户数据绝不入包）
WORK="$(mktemp -d "${TMPDIR:-/tmp}/opsupd.XXXXXX")"
trap 'rm -rf "$WORK"' EXIT
ZIP_NAME="ops-${VERSION}.zip"
python3 - "$REPO" "$WORK/$ZIP_NAME" "$CHANGED" <<'PY'
import os, sys, zipfile
repo, out, changed = sys.argv[1], sys.argv[2], sys.argv[3].splitlines()
FORBIDDEN = ("data/", "llm.json", ".db", ".env", "secrets.json", "mcp.json", "term-fixes.json", "evolve.json")
SKIP_PREFIX = ("docs/OPS-", "docs/radar-", "dist/", ".update-last-publish")

def add(dst, arcname, path):
    if any(b in arcname for b in FORBIDDEN) or arcname.startswith(SKIP_PREFIX):
        return
    if not os.path.isfile(path):
        return
    zi = zipfile.ZipInfo(arcname, date_time=(2026, 1, 1, 0, 0, 0))
    zi.compress_type = zipfile.ZIP_DEFLATED
    if not arcname.isascii():
        zi.flag_bits |= 0x800
    with open(path, "rb") as f:
        dst.writestr(zi, f.read())

with zipfile.ZipFile(out, "w") as z:
    for rel in changed:
        add(z, rel, os.path.join(repo, rel))
    # web/dist 全量
    root = os.path.join(repo, "web", "dist")
    for dp, _, fns in os.walk(root):
        for fn in fns:
            p = os.path.join(dp, fn)
            add(z, os.path.relpath(p, repo), p)
    # package.json 必带（版本号）
    add(z, "package.json", os.path.join(repo, "package.json"))
    print(f"   ✓ {os.path.basename(out)}：{len(z.namelist())} 个文件")
PY

SHA="$(shasum -a 256 "$WORK/$ZIP_NAME" | cut -d' ' -f1)"
SIZE="$(stat -f%z "$WORK/$ZIP_NAME")"
echo "   包大小：$(( SIZE / 1024 )) KB，sha256=${SHA:0:12}…"

# 4) 写入发布仓（首次自动创建公开仓）
ZIP_URL="https://cdn.jsdelivr.net/gh/${GH_REPO}@v${VERSION}/pkgs/${ZIP_NAME}"
MANIFEST="$(python3 - "$VERSION" "$ZIP_URL" "$SHA" "$SIZE" "$NOTES" <<'PY'
import json, math, sys, time
version, url, sha, size, notes = sys.argv[1:6]
n = [s for s in notes.split(";") if s.strip()]
print(json.dumps({
  "version": version, "zipUrl": url, "sha256": sha, "sizeBytes": int(size),
  "notes": n, "publishedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
}, ensure_ascii=False, indent=2))
PY
)"
echo "-- 发布仓写入"
if [ "$DRY" = "1" ]; then
  echo "（dry-run：以下内容未上传）"; echo "$MANIFEST"; echo "  zip 与 manifest 在 $WORK（退出即清）"; exit 0
fi
gh auth status >/dev/null 2>&1 || { echo "[错误] gh 未登录——先跑：gh auth login（一次即可）" >&2; exit 1; }

CLONE="$(mktemp -d "${TMPDIR:-/tmp}/opsrel.XXXXXX")"
trap 'rm -rf "$WORK" "$CLONE"' EXIT
if gh repo view "$GH_REPO" >/dev/null 2>&1; then
  git clone "https://github.com/${GH_REPO}" "$CLONE/repo" --depth 1
else
  echo "   发布仓不存在——创建（公开仓，仅存放更新包与清单）：${GH_REPO}"
  gh repo create "$GH_REPO" --public --description "OPS 更新通道（更新包与清单）" >/dev/null
  git clone "https://github.com/${GH_REPO}" "$CLONE/repo" --depth 1
fi
mkdir -p "$CLONE/repo/pkgs"
cp "$WORK/$ZIP_NAME" "$CLONE/repo/pkgs/$ZIP_NAME"
printf '%s\n' "$MANIFEST" > "$CLONE/repo/ops-update.json"
(
  cd "$CLONE/repo"
  git add -A
  git -c user.name="ops-release" -c user.email="ops-release@local" commit -m "release: v${VERSION}" -q
  git push -q origin HEAD
  git tag "v${VERSION}"
  git push -q origin "v${VERSION}"
)

# 5) purge jsDelivr（manifest 固定 URL + 本版 zip）
for u in "https://cdn.jsdelivr.net/gh/${GH_REPO}@main/ops-update.json" "https://cdn.jsdelivr.net/gh/${GH_REPO}@v${VERSION}/pkgs/${ZIP_NAME}"; do
  curl -s "https://purge.jsdelivr.net/gh/${GH_REPO%@*}" >/dev/null 2>&1 || true
done
curl -s "https://purge.jsdelivr.net/${u#https://cdn.jsdelivr.net/}" >/dev/null 2>&1 || true

# 6) 记录发布点
git rev-parse HEAD > "$LAST_FILE"

echo "== 发布完成 =="
echo "   manifest：https://cdn.jsdelivr.net/gh/${GH_REPO}@main/ops-update.json"
echo "   用户端：25 秒内自动看到「新版本 v${VERSION} 可用」横幅（或在页面手动检查）"
echo "   首次使用：把 src/update/source.ts 的 GIST_ID 占位替换为该 manifest URL 对应的仓库路径（见其上注释）"
