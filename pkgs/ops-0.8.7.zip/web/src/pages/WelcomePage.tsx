import { apiFetch } from "../errors";
/**
 * 首启向导（/welcome）：点开就知道怎么用——三步、大按钮、零术语。
 *   ① 接入 AI 大脑（一键用本机 Claude Code / 粘贴 DeepSeek Key / 更多模型）
 *   ② 导入你的数据（可选；本机发现历史数据时一键）
 *   ③ 开始使用
 */
import { useEffect, useState } from "react";
import {
  fetchOnboardingStatus,
  onboardingImport,
  onboardingSetup,
  type OnboardingStatus,
} from "./pagesApi";
import { TutorialVideoButton } from "../components/TutorialVideo";

type Step1State = { status: "idle" | "working" | "ok" | "error"; detail?: string };

export function WelcomePage({ onDone, onRefreshOverview }: { onDone: () => void; onRefreshOverview: () => void }) {
  const [status, setStatus] = useState<OnboardingStatus | null>(null);
  const [s1, setS1] = useState<Step1State>({ status: "idle" });
  const [key, setKey] = useState("");
  const [providers, setProviders] = useState<Array<{ id: string; name: string; model: string | null; models: string[] }> | null>(null);
  const [selModel, setSelModel] = useState("");
  const [showProviders, setShowProviders] = useState(false);
  const [selProvider, setSelProvider] = useState("deepseek");
  const [showCustom, setShowCustom] = useState(false);
  const [customUrl, setCustomUrl] = useState("");
  const [customModel, setCustomModel] = useState("");
  const [importState, setImportState] = useState<{ status: "idle" | "working" | "ok" | "skip"; detail?: string }>({ status: "idle" });

  useEffect(() => {
    void fetchOnboardingStatus().then(setStatus).catch(() => setStatus(null));
    void loadProviderList();
  }, []);

  async function connect(mode: "claude" | "key" | "provider" | "custom"): Promise<void> {
    setS1({ status: "working" });
    const body =
      mode === "claude"
        ? { mode }
        : mode === "key"
          ? { mode, providerId: "deepseek", key, ...(selModel.length > 0 ? { model: selModel } : {}) }
          : mode === "custom"
            ? { mode, key, baseUrl: customUrl, model: customModel }
            : { mode, providerId: selProvider, key, ...(selModel.length > 0 ? { model: selModel } : {}) };
    const r = await onboardingSetup(body);
    if (r.ok) {
      setS1({ status: "ok", detail: `已连接（${r.model ?? r.provider}）：${r.reply ?? ""}` });
      onRefreshOverview();
    } else {
      setS1({ status: "error", detail: r.error ?? "连接失败" });
    }
  }

  async function loadProviderList(): Promise<void> {
    if (providers !== null) return;
    // 供应商目录（复用 /api/models；含每家的模型清单 → 模型下拉）
    const res = await apiFetch("/api/models").catch(() => null);
    if (res !== null && res.ok) {
      const b = (await res.json()) as {
        providers: Array<{ id: string; name: string; model: string | null; models?: string[]; connectable: boolean }>;
      };
      const list = b.providers
        .filter((p) => p.connectable)
        .map((p) => ({ id: p.id, name: p.name, model: p.model, models: p.models ?? (p.model !== null ? [p.model] : []) }));
      setProviders(list);
      const d = list.find((p) => p.id === "deepseek") ?? list[0];
      if (d !== undefined) setSelModel(d.models[0] ?? "");
    } else {
      setProviders([]);
    }
  }

  async function loadProviders(): Promise<void> {
    setShowProviders(true);
    await loadProviderList();
  }

  async function doImport(): Promise<void> {
    setImportState({ status: "working" });
    const r = await onboardingImport();
    if (r.ok) {
      setImportState({ status: "ok", detail: `已导入 ${r.total ?? 0} 条（${(r.tables ?? []).map((t) => `${t.table}×${t.n}`).slice(0, 3).join("、")}…）` });
      onRefreshOverview();
    } else {
      setImportState({ status: "skip", detail: r.error });
    }
  }

  const box: React.CSSProperties = { background: "var(--ops-panel)", border: "1px solid var(--ops-border)", borderRadius: "var(--ops-radius)", padding: "18px 20px", marginBottom: 14 };
  const bigBtn: React.CSSProperties = { padding: "12px 18px", fontSize: 15, borderRadius: "var(--ops-radius)", cursor: "pointer" };
  const providerModels = (pid: string): string[] => providers?.find((p) => p.id === pid)?.models ?? [];
  const deepseekModels = providerModels("deepseek");

  return (
    <div className="ops-page" style={{ maxWidth: 760 }}>
      <h1 style={{ fontSize: 22, marginBottom: 2 }}>欢迎使用 OPS个人运营助手 👋</h1>
      <div className="ops-page-sub">三步开始，约 1 分钟。不用担心术语，跟着点就行。</div>

      <div style={{ ...box, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <div>
          <div style={{ fontWeight: 650 }}>🎬 先看完整教程视频（约 5 分钟，可选）</div>
          <div className="ops-faint" style={{ marginTop: 2 }}>从接入 AI 到第一条复盘，每一屏都看得见点什么、输什么。</div>
        </div>
        <TutorialVideoButton />
      </div>

      <div style={box}>
        <div style={{ fontWeight: 650, fontSize: 15, marginBottom: 4 }}>第 1 步 · 接入 AI 大脑（必做）</div>
        <div className="ops-faint" style={{ marginBottom: 10 }}>选一种方式，连上就能开工：</div>
        {s1.status === "ok" ? (
          <div className="ops-ok-box">✅ {s1.detail}</div>
        ) : (
          <>
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              <button
                className="ops-btn"
                style={{ ...bigBtn, textAlign: "left" }}
                disabled={s1.status === "working"}
                onClick={() => void connect("claude")}
              >
                ⚡ <b>用本机已登录的 Claude Code</b>——什么都不用输入，直接连
              </button>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                <input
                  className="ops-input"
                  style={{ flex: "1 1 240px", padding: "10px 12px" }}
                  type="password"
                  placeholder="有 DeepSeek Key？粘贴到这里（sk-…）"
                  value={key}
                  onChange={(e) => setKey(e.target.value)}
                />
                {deepseekModels.length > 0 ? (
                  <select
                    className="ops-input"
                    style={{ flex: "0 0 180px", padding: "10px 12px" }}
                    value={selModel}
                    disabled={s1.status === "working"}
                    onChange={(e) => setSelModel(e.target.value)}
                    title="选择模型（换模型不用换 Key）"
                  >
                    {deepseekModels.map((m) => (
                      <option key={m} value={m}>
                        {m}
                      </option>
                    ))}
                  </select>
                ) : null}
                <button className="ops-btn primary" style={bigBtn} disabled={s1.status === "working" || key.trim().length === 0} onClick={() => void connect("key")}>
                  {s1.status === "working" ? "连接中…" : "连接"}
                </button>
              </div>
              <div className="ops-faint" style={{ marginTop: -4 }}>
                没有 Key？打开 platform.deepseek.com 注册 → 创建 API Key（sk- 开头）→ 复制粘贴到这里。充 10 块钱够用很久。
              </div>
              <button className="ops-btn" style={{ ...bigBtn, textAlign: "left", color: "var(--ops-text-dim)" }} onClick={() => void loadProviders()}>
                🔑 用其他模型（94 家：智谱/Kimi/千问/OpenAI 兼容…）{showProviders ? " ▴" : " ▾"}
              </button>
              {showProviders ? (
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  <select
                    className="ops-input"
                    style={{ flex: "1 1 220px", padding: "10px 12px" }}
                    value={selProvider}
                    onChange={(e) => {
                      const id = e.target.value;
                      setSelProvider(id);
                      setSelModel(providerModels(id)[0] ?? "");
                    }}
                  >
                    {(providers ?? []).map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name}
                        {p.model !== null ? `（默认 ${p.model}）` : ""}
                      </option>
                    ))}
                    {providers !== null && providers.length === 0 ? <option value="deepseek">DeepSeek</option> : null}
                  </select>
                  {providerModels(selProvider).length > 0 ? (
                    <select
                      className="ops-input"
                      style={{ flex: "0 0 190px", padding: "10px 12px" }}
                      value={selModel}
                      disabled={s1.status === "working"}
                      onChange={(e) => setSelModel(e.target.value)}
                      title="选择模型（换模型不用换 Key）"
                    >
                      {providerModels(selProvider).map((m) => (
                        <option key={m} value={m}>
                          {m}
                        </option>
                      ))}
                    </select>
                  ) : null}
                  <button className="ops-btn primary" style={bigBtn} disabled={s1.status === "working" || key.trim().length === 0} onClick={() => void connect("provider")}>
                    连接
                  </button>
                </div>
              ) : null}
              <button
                className="ops-btn"
                style={{ ...bigBtn, textAlign: "left", color: "var(--ops-text-dim)" }}
                onClick={() => setShowCustom((v) => !v)}
              >
                🛰️ 中转站 / 自建服务（填地址+密钥）{showCustom ? " ▴" : " ▾"}
              </button>
              {showCustom ? (
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  <input
                    className="ops-input"
                    style={{ flex: "1 1 260px", padding: "10px 12px" }}
                    placeholder="服务地址（如 https://你的中转站.com/api/anthropic）"
                    value={customUrl}
                    onChange={(e) => setCustomUrl(e.target.value)}
                  />
                  <input
                    className="ops-input"
                    style={{ flex: "1 1 180px", padding: "10px 12px" }}
                    placeholder="模型名（可留空，默认 claude-sonnet-5）"
                    value={customModel}
                    onChange={(e) => setCustomModel(e.target.value)}
                  />
                  <button
                    className="ops-btn primary"
                    style={bigBtn}
                    disabled={s1.status === "working" || key.trim().length === 0 || customUrl.trim().length === 0}
                    onClick={() => void connect("custom")}
                  >
                    连接
                  </button>
                  <div className="ops-faint" style={{ flexBasis: "100%" }}>密钥用上面那个输入框（填过一次即可）。地址填中转站给你的 Anthropic 兼容地址。</div>
                </div>
              ) : null}
            </div>
            {s1.status === "working" ? <div className="ops-faint" style={{ marginTop: 8 }}>正在连接并试跑一次…（约 5-20 秒）</div> : null}
            {s1.status === "error" ? <div className="ops-inline-error" style={{ marginTop: 8 }}>❌ {s1.detail}</div> : null}
          </>
        )}
      </div>

      <div style={box}>
        <div style={{ fontWeight: 650, fontSize: 15, marginBottom: 4 }}>第 2 步 · 导入你的内容数据（可选）</div>
        {status !== null && status.contentCount > 0 && importState.status !== "ok" ? (
          <div className="ops-ok-box">✅ 已发现 {status.contentCount} 条内容数据——无需再导入，直接下一步。</div>
        ) : importState.status === "ok" ? (
          <div className="ops-ok-box">✅ {importState.detail}</div>
        ) : (
          <>
            <div className="ops-faint" style={{ marginBottom: 10 }}>
              {status?.opsCreatorFound === false
                ? "本机没发现历史数据——先跳过，之后在「设置」里随时导入。"
                : "发现本机有历史账号数据，一键带进来（只读导入，不改原文件）。"}
            </div>
            <button className="ops-btn" style={bigBtn} disabled={importState.status === "working" || status?.opsCreatorFound === false} onClick={() => void doImport()}>
              {importState.status === "working" ? "导入中…" : "一键导入我的数据"}
            </button>
            {importState.status === "skip" ? <div className="ops-faint" style={{ marginTop: 8 }}>{importState.detail}</div> : null}
          </>
        )}
      </div>

      <div style={box}>
        <div style={{ fontWeight: 650, fontSize: 15, marginBottom: 10 }}>第 3 步 · 开始使用</div>
        <button className="ops-btn primary" style={{ ...bigBtn, fontSize: 16 }} onClick={onDone}>
          进入工作台 →
        </button>
        <div className="ops-faint" style={{ marginTop: 8 }}>
          进去以后：左边选功能（选题/脚本/数据/电商…），底部随时跟助手说话（「帮我规划这周的选题」）。
        </div>
        <div className="ops-faint" style={{ marginTop: 6 }}>
          第一次用建议先过一遍：<a href="#/guide">打开新手教程 →</a>
        </div>
      </div>

      <button className="ops-nav-item" style={{ display: "inline-block", width: "auto", color: "var(--ops-text-faint)" }} onClick={onDone}>
        跳过向导，直接进工作台
      </button>
    </div>
  );
}
