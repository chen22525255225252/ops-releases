/**
 * 新手教程悬浮窗（可关闭 / 随时复看；任何页面状态都能呼出——含未填 Key 的首启态）。
 * 内容 = 六步主线 + 全部功能 79 项（A–F 六域折叠）+ 技巧 + FAQ + 90 秒视频入口。
 * 纯静态：不调后端、零 token。
 */
import { useEffect } from "react";
import { TutorialVideoButton } from "./TutorialVideo";

/** 任意组件调用它呼出教程窗（App 顶层监听并挂载 GuideWindow） */
export function openGuide(): void {
  window.dispatchEvent(new CustomEvent("ops-open-guide"));
}

interface GuideStep {
  title: string;
  what: string;
  route?: string;
  routeLabel?: string;
}

const STEPS: GuideStep[] = [
  {
    title: "接入你自己的 AI 模型",
    what: "软件不内置任何密钥。首次打开会强制这一步：选服务商（推荐 DeepSeek，便宜快）→ 粘贴你自己的 API Key → 点「接入并验证」。以后想换模型：F 区 → 模型接入。",
    route: "/models",
    routeLabel: "打开模型接入",
  },
  {
    title: "（可选）把账号数据导进来",
    what: "有创作者中心导出的数据表就导入——软件才能算完播率、做复盘、长账号 DNA。没有数据也能先玩对话和出稿。",
    route: "/welcome",
    routeLabel: "打开导入向导",
  },
  {
    title: "先和运营助手聊一句",
    what: "首页就是对话页。试一句：「帮我看看这周有什么可做的选题」——它带着你的真实数据回答，不空谈。",
    route: "/chat",
    routeLabel: "去对话",
  },
  {
    title: "建第一条选题",
    what: "在「A · 生产 → 选题」登记想做的题（或直接让助手在对话里替你出几条）；每条选题后面可以一键出稿。",
    route: "/topics",
    routeLabel: "去选题",
  },
  {
    title: "出稿，然后检查",
    what: "「脚本」里生成口播稿（标题/标签/口播/简介四件套）；发之前去「评分与风险」过一遍机械质检和风险检查，别裸发。",
    route: "/script",
    routeLabel: "去写稿",
  },
  {
    title: "发布前先预测，发布后做复盘",
    what: "发布前在「预测」登记一条（播放量估个区间就行）；数据出来后去「复盘」回填实绩。坚持几轮，软件会积累「你账号自己的经验库」。",
    route: "/predict",
    routeLabel: "去预测",
  },
];

interface Feature {
  label: string;
  route: string;
  what: string;
}

interface Domain {
  letter: string;
  title: string;
  desc: string;
  features: Feature[];
}

const DOMAINS: Domain[] = [
  {
    letter: "A",
    title: "生产闭环",
    desc: "一条主线：选题 → 脚本 → 检查 → 预测 → 发布 → 复盘。",
    features: [
      { label: "总览", route: "/overview", what: "一屏看今天该做什么、各环节的待办和最近动态。" },
      { label: "选题", route: "/topics", what: "候选选题池：分级排序、行内决策，选中的进入制作。" },
      { label: "选题来源", route: "/topics/discovery", what: "从热点、对标、评论里找新选题线索。" },
      { label: "脚本", route: "/script", what: "出稿台账：标题/标签/口播/简介四件套，带引用出处。" },
      { label: "脚本版本与分镜", route: "/script/variants", what: "同一选题的多版本管理 + 分镜。" },
      { label: "评分与风险", route: "/scoring", what: "编导审稿：机械质检 + 风险检查 + 评分依据。" },
      { label: "文稿机械质检", route: "/scoring/editorial", what: "错字、术语、格式的发布前机器检查。" },
      { label: "评分证据", route: "/scoring/evidence", what: "每条评分的计算依据，可展开对账。" },
      { label: "评论洞察", route: "/topics/comments", what: "观众最想问什么 → 变成选题候选。" },
      { label: "长视频切片", route: "/script/clips", what: "长视频自动找点，变成多条短视频。" },
      { label: "视频镜头", route: "/script/video-frames", what: "抽帧看画面（内置解码，不需要装 ffmpeg）。" },
      { label: "预测", route: "/predict", what: "发布前登记一条盲预测：估个区间，锁定后不可改（防自我暗示）。" },
      { label: "预测对照", route: "/predict/comparison", what: "预测和实际摆在一起看偏差。" },
      { label: "发布", route: "/publish", what: "发布登记与闸门：登记发布、跟踪状态。" },
      { label: "多平台发布目标", route: "/publish/targets", what: "各平台限制一览（抖音/小红书…）与交接方式。" },
      { label: "内容产物链", route: "/publish/pipeline", what: "从定稿到发布材料的流水线视图。" },
      { label: "发布排期", route: "/publish/schedule", what: "什么时候发：排期表。" },
      { label: "复盘", route: "/retro", what: "预测 vs 实际：落点判定和偏差归因。" },
      { label: "复盘对照", route: "/retro/comparison", what: "多轮复盘横向对比，看趋势。" },
    ],
  },
  {
    letter: "B",
    title: "智库",
    desc: "账号的外部输入：知识、爆款、对标、调研——都带证据。",
    features: [
      { label: "知识库", route: "/knowledge", what: "出稿时按话题自动找资料并带回源引用；账号知识与升级知识分家。" },
      { label: "知识关系与体检", route: "/knowledge/graph", what: "知识之间的关系图和孤岛体检。" },
      { label: "来源方法卡", route: "/knowledge/method-cards", what: "外部方法论的卡片（每条标明出处）。" },
      { label: "知识证据", route: "/knowledge/evidence", what: "每条知识的证据链，可回源核对。" },
      { label: "自升级", route: "/evolve", what: "扫描开源项目 → 蒸馏成方法/能力 → 你审核后才生效。" },
      { label: "技能路由与边界", route: "/evolve/skill-routing", what: "哪个技能管哪类任务、边界在哪。" },
      { label: "能力版本与对比", route: "/evolve/abilities", what: "能力的版本、提案、只读对比与停用恢复。" },
      { label: "开源更新雷达", route: "/evolve/radar", what: "盯关注的开源项目有没有新动静。" },
      { label: "爆款库", route: "/viral", what: "收录真实爆款作品备查。" },
      { label: "爆款结构", route: "/viral/patterns", what: "从真实爆款归纳值得借鉴的写法（带适用范围和证据）。" },
      { label: "对标", route: "/benchmark", what: "对标账号的作品与数据（可粘链接转写）。" },
      { label: "对标比较", route: "/benchmark/comparison", what: "我和对标：差距在哪、哪条值得学。" },
      { label: "转写校对", route: "/benchmark/transcripts", what: "链接转逐字稿的校对台（本地转写，不花云端额度）。" },
      { label: "多源搜索", route: "/research/sources", what: "一个入口搜多站资料（GitHub / B站 / 微博等）。" },
    ],
  },
  {
    letter: "C",
    title: "数据",
    desc: "作品表现放一起看，复盘才有据。",
    features: [
      { label: "数据与流量", route: "/traffic", what: "作品表现总览：播放、完播、互动。" },
      { label: "流量明细", route: "/traffic/evidence", what: "单条作品的明细数据表。" },
      { label: "成本", route: "/cost", what: "模型调用记录：每次花了多少、用了多少。" },
      { label: "成本明细", route: "/cost/breakdown", what: "按场景 / 模型拆开算钱。" },
    ],
  },
  {
    letter: "D",
    title: "账号",
    desc: "账号状态、诊断与 DNA。",
    features: [
      { label: "账号监控", route: "/monitor", what: "登录态、同步作品、一键初始化：先看状态，再看哪些作品值得改。" },
      { label: "监控洞察", route: "/monitor/insights", what: "诊断引擎的发现和建议（带证据）。" },
      { label: "账号与 DNA", route: "/dna", what: "三根支柱、播放分位、文案指纹、衰减提醒——从你账号自己的数据长出的画像。" },
      { label: "DNA 证据", route: "/dna/insights", what: "每条 DNA 结论背后的证据。" },
      { label: "浏览器步骤", route: "/monitor/browser-tasks", what: "后台网页任务（抓取/同步）的执行记录。" },
    ],
  },
  {
    letter: "E",
    title: "电商 / 跨境",
    desc: "先选国内或跨境，再按当前目标找工具。",
    features: [
      { label: "电商", route: "/ecommerce", what: "电商总入口：你在哪一步？选个目标，按顺序用工具。" },
      { label: "经营周报", route: "/ecommerce/weekly-report", what: "一周店铺经营自动成报。" },
      { label: "多店经营", route: "/ecommerce/store-dashboard", what: "多店铺同屏对比。" },
      { label: "退场情景", route: "/ecommerce/exit-decision", what: "该不该继续：算清退场线。" },
      { label: "节日倒排", route: "/ecommerce/seasonal-radar", what: "节日 / 旺季倒排选品。" },
      { label: "数据接入", route: "/ecommerce/market-data", what: "导入店铺 / 平台数据。" },
      { label: "1688 找货", route: "/ecommerce/sourcing-match", what: "按货找源头供应商。" },
      { label: "FBM 套利", route: "/ecommerce/fbm-arbitrage", what: "套利公式测算（含盈亏平衡价）。" },
      { label: "利润测算", route: "/ecommerce/profit-calculator", what: "采购/售价/费用 → 净利率。" },
      { label: "词覆盖", route: "/ecommerce/listing-coverage", what: "Listing 关键词覆盖检查。" },
      { label: "Listing 优化", route: "/ecommerce/listing-optimize", what: "Listing 改写建议。" },
      { label: "转化文案", route: "/ecommerce/conversion-copy", what: "商品页转化文案生成。" },
      { label: "Review 情绪", route: "/ecommerce/review-sentiment", what: "买家评价情绪与差评点分析。" },
      { label: "蓝海选品", route: "/ecommerce/blue-ocean", what: "找竞争小、需求大的品。" },
      { label: "类目趋势", route: "/ecommerce/category-trend", what: "类目大盘走势。" },
      { label: "竞品证据", route: "/ecommerce/competitor-360", what: "竞品全方位证据卡。" },
      { label: "关键词反查", route: "/ecommerce/keyword-reverse", what: "反查竞品的流量词。" },
      { label: "长尾词", route: "/ecommerce/long-tail", what: "长尾词挖掘。" },
      { label: "跟卖监控", route: "/ecommerce/hijacker-monitor", what: "谁在跟卖你的 listing。" },
      { label: "BSR监控", route: "/ecommerce/bsr-monitor", what: "销量排名追踪。" },
      { label: "关键词排名", route: "/ecommerce/keyword-rank", what: "目标词排名变化。" },
      { label: "Best Seller", route: "/ecommerce/best-seller", what: "Best Seller 榜单监控。" },
      { label: "跨境", route: "/crossborder", what: "跨境总入口。" },
      { label: "跨境 · 工作流", route: "/crossborder/workflow", what: "跨境铺货的工序流。" },
      { label: "跨境 · 商品迁移", route: "/crossborder/product-migration", what: "商品搬到另一个平台 / 站点。" },
      { label: "跨境 · 到手价", route: "/crossborder/price-compare", what: "各站点到手价对比。" },
      { label: "跨境 · TikTok反哺", route: "/crossborder/tiktok-amazon", what: "TikTok 热度反哺亚马逊选品与优化。" },
    ],
  },
  {
    letter: "F",
    title: "系统",
    desc: "连接、设置与低频工具。",
    features: [
      { label: "新手教程", route: "guide:self", what: "就是这个窗口——随时关掉、随时再开。" },
      { label: "应用设置", route: "/settings", what: "常规设置与数据接入快捷入口。" },
      { label: "智能体", route: "/agent", what: "内置多步智能体：它干活（查数据 / 写稿 / 整理文件），写操作弹审批卡，批准才执行。" },
      { label: "模型接入", route: "/models", what: "接入你自己的模型 Key（服务商 → 模型 → Key），可现场拉取模型清单。" },
      { label: "MCP", route: "/mcp", what: "外接工具（MCP 服务器）的登记与管理。" },
      { label: "模型健康", route: "/models/health", what: "供应商连通与延迟检查。" },
      { label: "MCP 工具检查", route: "/mcp/inspector", what: "看看外接工具都暴露了哪些能力。" },
      { label: "多渠道告警", route: "/settings/notifications", what: "任务 / 预测的提醒推到飞书、邮件等渠道。" },
      { label: "任务运行", route: "/settings/workflows", what: "后台任务跑到哪了。" },
      { label: "对话语境", route: "/settings/conversation-context", what: "对话记住了哪些资料。" },
    ],
  },
];

const TIPS: Array<[string, string]> = [
  ["⌘K / Ctrl+K", "想不起功能在哪？直接搜（试试「出稿」「完播率」「找爆款」）。"],
  ["首页 A–F 六大区块", "生产 / 智库 / 数据 / 账号 / 扩展 / 系统——二级菜单在区块页里。"],
  ["首页右下「找功能」", "和 ⌘K 是同一个搜索入口。"],
  ["右上角「历史会话」", "对话随时接着聊；「+ 新会话」开始新话题。"],
];

const FAQ: Array<[string, string]> = [
  ["我的数据存在哪？", "全在你本机：数据库、导入的数据、AI 密钥都只在你自己的电脑上（Mac 上密钥进系统钥匙串）。"],
  ["会花多少钱？", "按你自己 API Key 的账单走（DeepSeek 很便宜，日常测几天几块钱以内）；软件内「成本」页能看到每次调用花了多少。"],
  ["打不开 / 报错怎么办？", "截图发给作者即可。命令行用户也可以跑 `ops doctor` 出一份本机自检。"],
];

function GuideBody({ onNavigate }: { onNavigate: () => void }) {
  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="ops-card" style={{ margin: 0 }}>
        <h3>六步上手</h3>
        <ol style={{ margin: 0, paddingLeft: 20, display: "grid", gap: 14 }}>
          {STEPS.map((s) => (
            <li key={s.title}>
              <div style={{ fontWeight: 650 }}>{s.title}</div>
              <div className="ops-faint" style={{ margin: "3px 0 6px", lineHeight: 1.65 }}>{s.what}</div>
              {s.route !== undefined ? (
                <a className="ops-btn sm" href={`#${s.route}`} onClick={onNavigate}>
                  {s.routeLabel ?? "去做"} →
                </a>
              ) : null}
            </li>
          ))}
        </ol>
      </div>

      <div className="ops-card" style={{ margin: 0 }}>
        <h3>全部功能（{DOMAINS.reduce((n, d) => n + d.features.length, 0)} 项 · 点开各区块）</h3>
        <div style={{ display: "grid", gap: 6 }}>
          {DOMAINS.map((d) => (
            <details key={d.letter} style={{ borderTop: "1px dashed var(--ops-border)", padding: "6px 0" }}>
              <summary style={{ cursor: "pointer", padding: "2px 0" }}>
                <b>{d.letter} · {d.title}</b>
                <span className="ops-faint" style={{ marginLeft: 8, fontSize: 12.5 }}>{d.desc}（{d.features.length} 项）</span>
              </summary>
              <ul style={{ margin: "6px 0 2px", paddingLeft: 20, display: "grid", gap: 6 }}>
                {d.features.map((f) => (
                  <li key={f.route}>
                    {f.route === "guide:self" ? (
                      <b>{f.label}</b>
                    ) : (
                      <a href={`#${f.route}`} style={{ fontWeight: 600 }} onClick={onNavigate}>
                        {f.label}
                      </a>
                    )}
                    <span className="ops-faint"> — {f.what}</span>
                  </li>
                ))}
              </ul>
            </details>
          ))}
        </div>
      </div>

      <div className="ops-card" style={{ margin: 0 }}>
        <h3>找东西的四个技巧</h3>
        <table className="ops-table">
          <tbody>
            {TIPS.map(([k, v]) => (
              <tr key={k}>
                <td style={{ whiteSpace: "nowrap", fontWeight: 600 }}>{k}</td>
                <td className="ops-faint">{v}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="ops-card" style={{ margin: 0 }}>
        <h3>常见问题</h3>
        <div style={{ display: "grid", gap: 10 }}>
          {FAQ.map(([q, a]) => (
            <div key={q}>
              <div style={{ fontWeight: 600 }}>{q}</div>
              <div className="ops-faint" style={{ marginTop: 2, lineHeight: 1.65 }}>{a}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/** 悬浮窗本体（由 App 顶层挂载；open=false 时什么都不渲染） */
export function GuideWindow({ open, onClose }: { open: boolean; onClose: () => void }) {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent): void => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;
  return (
    <div className="ops-guide-mask" onClick={onClose} role="dialog" aria-label="新手教程">
      <div className="ops-guide-win" onClick={(e) => e.stopPropagation()}>
        <div className="ops-guide-head">
          <div>
            <b style={{ fontSize: 16 }}>新手教程</b>
            <span className="ops-faint" style={{ marginLeft: 10, fontSize: 12.5 }}>
              六步主线 · 全部功能 {DOMAINS.reduce((n, d) => n + d.features.length, 0)} 项 · 随时关掉、随时再开
            </span>
          </div>
          <div className="ops-row-actions">
            <TutorialVideoButton label="▶ 完整教程（约 5 分钟）" />
            <button className="ops-btn" onClick={onClose}>
              ✕ 关闭
            </button>
          </div>
        </div>
        <div className="ops-guide-body">
          {/* 点任意「去做」直达后自动关窗（保留在目标页继续用） */}
          <GuideBody onNavigate={onClose} />
        </div>
      </div>
    </div>
  );
}
